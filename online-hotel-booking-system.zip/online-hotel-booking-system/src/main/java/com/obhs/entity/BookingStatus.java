package com.obhs.entity;

public enum BookingStatus {
    PENDING,
    CONFIRMED,
    CANCELED
}